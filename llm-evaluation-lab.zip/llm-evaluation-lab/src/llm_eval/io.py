"""Safe JSONL readers and writers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, TypeVar

from llm_eval.models import EvalExample, Prediction

T = TypeVar("T", EvalExample, Prediction)


def read_jsonl(path: str | Path, record_type: type[T]) -> list[T]:
    source = Path(path)
    records: list[T] = []
    with source.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            try:
                raw: Any = json.loads(line)
                if not isinstance(raw, dict):
                    raise ValueError("each JSONL line must be an object")
                records.append(record_type.from_dict(raw))  # type: ignore[attr-defined]
            except (json.JSONDecodeError, ValueError) as exc:
                raise ValueError(f"{source}:{line_number}: {exc}") from exc
    return records


def write_json(path: str | Path, payload: Any) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
