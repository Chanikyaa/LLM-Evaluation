"""Typed data models and strict JSONL parsing for evaluation records."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


class RecordError(ValueError):
    """Raised when an evaluation record is malformed."""


def _string_list(value: Any, field_name: str) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise RecordError(f"{field_name} must be a list of strings")
    return value


@dataclass(frozen=True)
class EvalExample:
    example_id: str
    split: str
    question: str
    relevant_doc_ids: list[str]
    reference_answer: str
    supporting_facts: list[str] = field(default_factory=list)
    expected_citations: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "EvalExample":
        required = ("example_id", "split", "question", "relevant_doc_ids", "reference_answer")
        missing = [key for key in required if key not in raw]
        if missing:
            raise RecordError(f"dataset record missing fields: {', '.join(missing)}")
        for key in ("example_id", "split", "question", "reference_answer"):
            if not isinstance(raw[key], str) or not raw[key].strip():
                raise RecordError(f"{key} must be a non-empty string")
        if raw["split"] not in {"dev", "test"}:
            raise RecordError("split must be 'dev' or 'test'")
        return cls(
            example_id=raw["example_id"],
            split=raw["split"],
            question=raw["question"],
            relevant_doc_ids=_string_list(raw["relevant_doc_ids"], "relevant_doc_ids"),
            reference_answer=raw["reference_answer"],
            supporting_facts=_string_list(raw.get("supporting_facts", []), "supporting_facts"),
            expected_citations=_string_list(raw.get("expected_citations", []), "expected_citations"),
        )


@dataclass(frozen=True)
class Prediction:
    example_id: str
    config_name: str
    retrieved_doc_ids: list[str]
    answer: str
    citations: list[str] = field(default_factory=list)
    latency_ms: float | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    cost_usd: float | None = None

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Prediction":
        required = ("example_id", "config_name", "retrieved_doc_ids", "answer")
        missing = [key for key in required if key not in raw]
        if missing:
            raise RecordError(f"prediction record missing fields: {', '.join(missing)}")
        for key in ("example_id", "config_name", "answer"):
            if not isinstance(raw[key], str) or not raw[key].strip():
                raise RecordError(f"{key} must be a non-empty string")
        numeric: dict[str, float | int | None] = {}
        for key in ("latency_ms", "input_tokens", "output_tokens", "cost_usd"):
            value = raw.get(key)
            if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float))):
                raise RecordError(f"{key} must be numeric or null")
            if value is not None and value < 0:
                raise RecordError(f"{key} cannot be negative")
            if key in {"input_tokens", "output_tokens"} and value is not None and not isinstance(value, int):
                raise RecordError(f"{key} must be an integer")
            numeric[key] = value
        return cls(
            example_id=raw["example_id"],
            config_name=raw["config_name"],
            retrieved_doc_ids=_string_list(raw["retrieved_doc_ids"], "retrieved_doc_ids"),
            answer=raw["answer"],
            citations=_string_list(raw.get("citations", []), "citations"),
            **numeric,
        )


def to_dict(record: Any) -> dict[str, Any]:
    """Convert a dataclass record to a JSON-compatible dictionary."""
    return asdict(record)
