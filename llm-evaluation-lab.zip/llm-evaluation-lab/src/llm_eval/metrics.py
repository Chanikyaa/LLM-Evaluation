"""Deterministic retrieval and answer-support metrics."""

from __future__ import annotations

import math
import re
from collections.abc import Sequence

from llm_eval.models import EvalExample, Prediction

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def recall_at_k(relevant: Sequence[str], ranked: Sequence[str], k: int = 5) -> float:
    if k < 1:
        raise ValueError("k must be >= 1")
    if not relevant:
        return 0.0
    return len(set(relevant) & set(ranked[:k])) / len(set(relevant))


def reciprocal_rank(relevant: Sequence[str], ranked: Sequence[str]) -> float:
    relevant_set = set(relevant)
    for index, item in enumerate(ranked, start=1):
        if item in relevant_set:
            return 1.0 / index
    return 0.0


def ndcg_at_k(relevant: Sequence[str], ranked: Sequence[str], k: int = 5) -> float:
    if k < 1:
        raise ValueError("k must be >= 1")
    relevant_set = set(relevant)
    dcg = sum(1.0 / math.log2(rank + 1) for rank, item in enumerate(ranked[:k], start=1) if item in relevant_set)
    ideal_hits = min(len(relevant_set), k)
    idcg = sum(1.0 / math.log2(rank + 1) for rank in range(1, ideal_hits + 1))
    return dcg / idcg if idcg else 0.0


def token_f1(prediction: str, reference: str) -> float:
    """Token-overlap F1; a lexical proxy, not a semantic correctness judge."""
    pred_tokens = _TOKEN_RE.findall(prediction.lower())
    ref_tokens = _TOKEN_RE.findall(reference.lower())
    if not pred_tokens or not ref_tokens:
        return float(pred_tokens == ref_tokens)
    from collections import Counter

    overlap = sum((Counter(pred_tokens) & Counter(ref_tokens)).values())
    if not overlap:
        return 0.0
    precision = overlap / len(pred_tokens)
    recall = overlap / len(ref_tokens)
    return 2 * precision * recall / (precision + recall)


def support_coverage(answer: str, supporting_facts: Sequence[str]) -> float:
    """Fraction of labeled support facts with non-zero lexical overlap in the answer."""
    if not supporting_facts:
        return 0.0
    answer_tokens = set(_TOKEN_RE.findall(answer.lower()))
    supported = 0
    for fact in supporting_facts:
        fact_tokens = set(_TOKEN_RE.findall(fact.lower()))
        if fact_tokens and answer_tokens.intersection(fact_tokens):
            supported += 1
    return supported / len(supporting_facts)


def citation_precision(citations: Sequence[str], valid_sources: Sequence[str]) -> float:
    """Share of emitted citations that refer to known source IDs; empty output scores 0."""
    if not citations:
        return 0.0
    valid = set(valid_sources)
    return sum(citation in valid for citation in citations) / len(citations)


def evaluate_one(example: EvalExample, prediction: Prediction, k: int = 5) -> dict[str, float | str | int]:
    return {
        "example_id": example.example_id,
        "config_name": prediction.config_name,
        f"recall@{k}": recall_at_k(example.relevant_doc_ids, prediction.retrieved_doc_ids, k),
        "mrr": reciprocal_rank(example.relevant_doc_ids, prediction.retrieved_doc_ids),
        f"ndcg@{k}": ndcg_at_k(example.relevant_doc_ids, prediction.retrieved_doc_ids, k),
        "answer_token_f1": token_f1(prediction.answer, example.reference_answer),
        "support_coverage": support_coverage(prediction.answer, example.supporting_facts),
        "citation_precision": citation_precision(prediction.citations, example.expected_citations),
        "latency_ms": prediction.latency_ms,
        "input_tokens": prediction.input_tokens,
        "output_tokens": prediction.output_tokens,
        "cost_usd": prediction.cost_usd,
    }
