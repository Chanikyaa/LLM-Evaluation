"""Evaluation orchestration and reproducible baseline demonstration."""

from __future__ import annotations

import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from llm_eval.io import read_jsonl, write_json
from llm_eval.metrics import evaluate_one
from llm_eval.models import EvalExample, Prediction


def evaluate(
    dataset_path: str | Path,
    predictions_path: str | Path,
    output_path: str | Path,
    split: str = "dev",
    k: int = 3,
    min_recall_at_k: float | None = None,
) -> dict[str, Any]:
    examples = [item for item in read_jsonl(dataset_path, EvalExample) if item.split == split]
    predictions = read_jsonl(predictions_path, Prediction)
    if not examples:
        raise ValueError(f"no examples found for split={split!r}")
    example_by_id = {item.example_id: item for item in examples}
    if len(example_by_id) != len(examples):
        raise ValueError(f"duplicate example_id in selected {split} split")
    prediction_by_id: dict[str, Prediction] = {}
    config_names: set[str] = set()
    for prediction in predictions:
        if prediction.example_id not in example_by_id:
            continue
        if prediction.example_id in prediction_by_id:
            raise ValueError(f"duplicate prediction for example_id={prediction.example_id!r}")
        prediction_by_id[prediction.example_id] = prediction
        config_names.add(prediction.config_name)
    missing = sorted(set(example_by_id) - set(prediction_by_id))
    if missing:
        raise ValueError(f"missing predictions for {split} examples: {', '.join(missing)}")
    if len(config_names) != 1:
        raise ValueError("one prediction file must contain exactly one config_name per run")

    per_example = [
        evaluate_one(example_by_id[pred.example_id], pred, k=k)
        for pred in predictions
        if pred.example_id in example_by_id
    ]
    metric_keys = [key for key in per_example[0] if key not in {"example_id", "config_name"}]
    summary: dict[str, float] = {}
    for key in metric_keys:
        values = [float(row[key]) for row in per_example if row[key] is not None]
        summary[key] = round(statistics.fmean(values), 6) if values else None
    summary["examples_evaluated"] = float(len(per_example))
    report: dict[str, Any] = {
        "schema_version": "1.0",
        "split": split,
        "k": k,
        "config_name": next(iter(config_names)),
        "dataset": str(dataset_path),
        "predictions": str(predictions_path),
        "summary": summary,
        "per_example": per_example,
        "interpretation_notes": [
            "Token F1 and support coverage are lexical proxies, not semantic truth or proof of groundedness.",
            "Citation precision checks IDs against labeled expected source IDs; it does not verify every claim in an answer.",
            "Missing latency, token, or cost fields are reported as null; null means unmeasured, not zero.",
        ],
    }
    write_json(output_path, report)
    if min_recall_at_k is not None and summary[f"recall@{k}"] < min_recall_at_k:
        raise EvaluationGateError(
            f"evaluation gate failed: recall@{k}={summary[f'recall@{k}']:.3f} "
            f"is below threshold {min_recall_at_k:.3f}; report written to {output_path}"
        )
    return report


class EvaluationGateError(RuntimeError):
    """Raised when a configured evaluation threshold is not met."""


def _overlap_score(query: str, text: str) -> float:
    import re

    def tokenize(value: str) -> set[str]:
        return set(re.findall(r"[a-z0-9]+", value.lower()))

    query_tokens = tokenize(query)
    return len(query_tokens & tokenize(text)) / max(1, len(query_tokens))


def make_demo_predictions(dataset_path: str | Path, output_dir: str | Path) -> list[Path]:
    """Create deterministic, clearly labeled synthetic baseline outputs for the sample corpus."""
    examples = read_jsonl(dataset_path, EvalExample)
    docs_path = Path(dataset_path).with_name("documents.json")
    documents = json.loads(docs_path.read_text(encoding="utf-8"))
    synonyms = {
        "quickly": {"within", "five", "minutes"}, "protect": {"privacy", "encrypt", "restrict"},
        "personal": {"data", "privacy"}, "quality": {"evaluation", "metrics"},
        "deployment": {"deploy", "service", "container"}, "credentials": {"access", "authorization"},
        "combine": {"fusion", "rankings", "ranked"}, "record": {"audit", "timeline"},
        "restrict": {"least", "privilege", "role"}, "quick": {"within", "minutes"},
    }

    def semantic_overlap(question: str, text: str) -> float:
        import re
        def tokenize(value: str) -> set[str]:
            return set(re.findall(r"[a-z0-9]+", value.lower()))

        query_tokens = tokenize(question)
        expanded = set(query_tokens)
        for token in query_tokens:
            expanded.update(synonyms.get(token, set()))
        document_tokens = tokenize(text)
        return len(expanded & document_tokens) / max(1, len(expanded))

    configs = {
        "bm25_demo": lambda ex, doc: _overlap_score(ex.question, doc["text"]),
        "semantic_proxy_demo": lambda ex, doc: semantic_overlap(ex.question, doc["text"]),
        "hybrid_demo": lambda ex, doc: 0.5 * _overlap_score(ex.question, doc["text"])
        + 0.5 * semantic_overlap(ex.question, doc["text"]),
    }
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for config_name, scorer in configs.items():
        records = []
        for example in examples:
            ranked = sorted(documents, key=lambda doc: (-scorer(example, doc), doc["doc_id"]))
            retrieved = [doc["doc_id"] for doc in ranked]
            # No answer generator is run: the explicit marker prevents oracle-label
            # answers or invented usage values from inflating answer/operating metrics.
            records.append({
                "example_id": example.example_id,
                "config_name": config_name,
                "retrieved_doc_ids": retrieved,
                "answer": "[retrieval-only demo: no answer generated]",
                "citations": [],
            })
        path = out_dir / f"{config_name}.jsonl"
        path.write_text("".join(json.dumps(row) + "\n" for row in records), encoding="utf-8")
        written.append(path)
    return written


def compare_reports(report_paths: list[str | Path], output_path: str | Path) -> dict[str, Any]:
    reports = [json.loads(Path(path).read_text(encoding="utf-8")) for path in report_paths]
    if not reports:
        raise ValueError("at least one report is required")
    comparable = {(report["split"], report["k"]) for report in reports}
    if len(comparable) != 1:
        raise ValueError("reports must use the same split and k to be compared")
    result = {
        "schema_version": "1.0",
        "comparison_type": "deterministic_demo" if all(name.endswith("_demo") for name in [r["config_name"] for r in reports]) else "evaluation_reports",
        "runs": [
            {"config_name": report["config_name"], "summary": report["summary"], "report": str(path)}
            for report, path in zip(reports, report_paths, strict=True)
        ],
    }
    write_json(output_path, result)
    return result
