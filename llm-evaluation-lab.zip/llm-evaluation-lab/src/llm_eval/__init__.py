"""Reproducible evaluation tools for retrieval-augmented and LLM applications."""

__version__ = "0.1.0"
