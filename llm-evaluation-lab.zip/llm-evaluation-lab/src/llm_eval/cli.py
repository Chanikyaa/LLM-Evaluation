"""Command-line interface for dataset evaluation and report comparison."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from llm_eval.runner import EvaluationGateError, compare_reports, evaluate, make_demo_predictions


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="llm-eval", description="Evaluate retrieval and LLM application outputs")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="evaluate one predictions JSONL file")
    run_parser.add_argument("--dataset", required=True)
    run_parser.add_argument("--predictions", required=True)
    run_parser.add_argument("--output", required=True)
    run_parser.add_argument("--split", choices=("dev", "test"), default="dev")
    run_parser.add_argument("-k", type=int, default=3)
    run_parser.add_argument("--min-recall-at-k", type=float)

    demo_parser = subparsers.add_parser("demo-predictions", help="generate deterministic demo baseline outputs")
    demo_parser.add_argument("--dataset", default="data/dataset.jsonl")
    demo_parser.add_argument("--output-dir", default="runs/predictions")

    compare_parser = subparsers.add_parser("compare", help="compare reports from the same split and k")
    compare_parser.add_argument("--reports", nargs="+", required=True)
    compare_parser.add_argument("--output", required=True)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        if args.command == "run":
            report = evaluate(args.dataset, args.predictions, args.output, args.split, args.k, args.min_recall_at_k)
            print(json.dumps({"config_name": report["config_name"], "summary": report["summary"]}, indent=2))
        elif args.command == "demo-predictions":
            for path in make_demo_predictions(args.dataset, args.output_dir):
                print(path)
        elif args.command == "compare":
            report = compare_reports(args.reports, args.output)
            print(json.dumps(report, indent=2))
    except (ValueError, OSError, json.JSONDecodeError, EvaluationGateError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2) from exc


if __name__ == "__main__":
    main()
