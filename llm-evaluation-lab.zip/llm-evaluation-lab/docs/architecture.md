# Architecture and data flow

The evaluation runner is deliberately separate from the application being evaluated. The target application produces a JSONL file of outputs and usage metadata; this project joins those records to a labeled dataset by `example_id`.

```mermaid
sequenceDiagram
    participant App as RAG / LLM app
    participant Data as Versioned dataset
    participant Eval as Evaluation runner
    participant Report as JSON report / CI
    App->>Eval: predictions.jsonl
    Data->>Eval: dataset.jsonl + split
    Eval->>Eval: Validate schemas and IDs
    Eval->>Eval: Compute retrieval and answer diagnostics
    Eval->>Report: Aggregate + per-example metrics
    Report->>Report: Optional threshold gate
```

## Boundaries

- This repository does not host the model or retrieve documents itself.
- Dataset labels are the evaluation ground truth; incorrect labels invalidate conclusions.
- The held-out test split is not for iterative tuning.
- Model-based judges can be added behind an interface, but should be calibrated against human labels and never treated as unquestionable truth.

## Failure modes

- Missing or duplicated prediction IDs fail validation.
- A metric can look high on a tiny or unrepresentative dataset.
- Lexical support metrics can miss paraphrases and accept misleading word overlap.
- Incomplete citations can appear precise because precision does not measure recall.
- Missing usage metadata is currently serialized as zero; inspect input records before drawing cost or latency conclusions.
