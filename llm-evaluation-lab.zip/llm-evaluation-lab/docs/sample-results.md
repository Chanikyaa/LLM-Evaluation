# Sample run results

These results were generated locally on 2026-10-25 using the bundled six-example development split and two-example held-out test split. The prediction generator uses deterministic lexical and hand-written synonym-expansion ranking proxies; it is **not** a real BM25 implementation or embedding model. This table demonstrates that the evaluator runs end to end, not that one retrieval approach generalizes better.

## Retrieval metrics at k=3

| Configuration | Split | Examples | Recall@3 | MRR | nDCG@3 |
|---|---|---:|---:|---:|---:|
| `bm25_demo` | dev | 6 | 1.000 | 1.000 | 1.000 |
| `semantic_proxy_demo` | dev | 6 | 1.000 | 1.000 | 1.000 |
| `hybrid_demo` | dev | 6 | 1.000 | 1.000 | 1.000 |
| `bm25_demo` | test | 2 | 1.000 | 0.750 | 0.815465 |
| `semantic_proxy_demo` | test | 2 | 1.000 | 1.000 | 1.000 |
| `hybrid_demo` | test | 2 | 1.000 | 0.750 | 0.815465 |

## Interpretation

- The development set does not distinguish these proxies; every relevant document happened to rank within the top three.
- On only two held-out examples, the semantic proxy ranks the first relevant result earlier. This is a fragile observation, not evidence of a real semantic retrieval benefit.
- The demo deliberately does not generate answers. Answer token F1 and support coverage are therefore not useful quality results, citations are absent, and latency/token/cost metrics are `null` because they were not measured.
- The next valid experiment is to export predictions from actual BM25, actual embedding-based dense retrieval, and a fusion configuration against a larger independently labeled corpus. Report development and held-out results without tuning on the test split.
