# Career-readiness guide

## Target roles and skills

- **AI / Generative AI Engineer:** evaluation design, RAG regression tests, citation diagnostics, experiment comparison.
- **Machine Learning Engineer:** dataset versioning, reproducibility, metric implementation, CI gates.
- **MLOps Engineer:** automated quality gates, machine-readable reports, failure visibility, repeatable execution.
- **Data Scientist:** metric interpretation, held-out evaluation, error analysis, honest limitations.

## Requirement-to-feature mapping

| Job requirement | Evidence in this repository |
|---|---|
| Evaluate retrieval | Recall@k, MRR, nDCG@k |
| Evaluate generated answers | Token F1 and labeled support coverage, with documented limitations |
| Track citations | Citation ID precision diagnostic |
| Reproducible experiments | JSONL dataset/prediction formats and JSON reports |
| Prevent regressions | Threshold gate and CI tests |
| Measure operating cost | Optional latency, token, and cost aggregation |

## Resume bullet templates

1. Built a provider-agnostic LLM evaluation CLI implementing Recall@k, MRR, nDCG, answer-overlap diagnostics, and citation-ID checks across **[N] labeled examples**.
2. Added a CI quality gate that blocks changes when **[metric]** falls below **[threshold]**, reducing **[verified regression class]** in **[measured evaluation period]**.
3. Compared **[N]** retrieval/prompt configurations on a held-out dataset, identifying **[verified failure pattern]** and reporting **[measured metric and confidence/limitations]**.

Do not fill placeholders until you have run and reviewed your own experiments.

## Measurable results to collect

- Dataset size, domain coverage, label agreement, and split policy.
- Recall@k, MRR, nDCG@k for each configuration.
- Human-rated answer correctness and groundedness on a representative sample.
- Citation precision and recall, including claim-level support.
- p50/p95 latency, tokens per request, and cost per request when real provider data is available.
- Number and type of regressions caught by CI.
- Repeated-run variation for stochastic models.

## Five-minute demonstration script

1. **0:00–0:45:** Explain why prompt/model changes need regression tests.
2. **0:45–1:30:** Show the dataset schema and explain dev/test separation.
3. **1:30–2:30:** Run the demo prediction generator and evaluate two configurations.
4. **2:30–3:30:** Open the JSON report and inspect a per-example failure.
5. **3:30–4:15:** Trigger a deliberately high Recall@k threshold and show that the command fails after writing its report.
6. **4:15–5:00:** Explain limitations of lexical metrics and the next step: human-labeled answer evaluation.

## Two-minute architecture explanation

“The evaluated application writes one JSONL record per example, including retrieved document IDs, answer, citations, and optional usage data. The evaluator joins these outputs to a versioned labeled dataset by example ID and split. It calculates retrieval ranking metrics, lexical answer diagnostics, citation-ID precision, and optional operating metrics. It writes aggregate and per-example results, then can apply a configurable CI threshold. The runner is provider-agnostic and offline by default. Its key limitation is that lexical overlap is not semantic correctness, so a production evaluation would add human-labeled correctness and claim-level citation support.”

## 20 technical interview questions and answers

1. **Why evaluate retrieval separately from answer generation?** Retrieval and generation fail for different reasons. Separate metrics help isolate whether relevant evidence was missed or the model mishandled evidence it received.
2. **What is Recall@k?** The fraction of labeled relevant documents present in the top k retrieved documents. It measures coverage, not ranking order among the hits.
3. **What is MRR?** The mean reciprocal rank of the first relevant result. A relevant item at rank one contributes 1; at rank four it contributes 0.25.
4. **What does nDCG measure?** Ranking quality with position discount and normalization against an ideal ranking. This implementation uses binary relevance labels.
5. **Why not use accuracy for retrieval?** Retrieval is a ranked list with multiple potentially relevant documents; accuracy generally assumes a single class prediction and does not capture ranking quality well.
6. **What is data leakage in evaluation?** Information from held-out examples influences training, prompt selection, threshold tuning, or model choices, making the reported test result optimistic.
7. **Why have dev and test splits?** Development data supports iterative choices; test data estimates final performance after choices are fixed.
8. **What is token F1?** Precision/recall F1 over token overlap. It is deterministic and cheap but penalizes valid paraphrases and can reward shared words without factual agreement.
9. **Does support coverage prove groundedness?** No. It checks lexical overlap with labeled support facts and cannot verify entailment or whether each claim is supported.
10. **What is citation precision?** The fraction of emitted citation IDs that are valid under the labeling scheme. Citation recall is separately needed to detect missing citations.
11. **Why report per-example metrics?** Aggregate scores hide tail failures and allow targeted debugging of queries, documents, prompts, and parsing.
12. **How would you evaluate an LLM judge?** Compare it with blinded human ratings on a representative labeled set, measure agreement and bias, version the judge, and inspect disagreements.
13. **Why are deterministic metrics useful in CI?** They reduce noise and make regressions reproducible, though the dataset and labels must still be representative.
14. **How should stochastic outputs be evaluated?** Use fixed seeds where supported, multiple runs when needed, and report variation rather than selecting the best run.
15. **How would you measure cost?** Capture provider-reported token usage, apply versioned pricing assumptions, and report cost per request and distribution; don't infer cost from answer length alone.
16. **Why include latency?** A quality gain may be unacceptable if latency or cost rises too much. Report percentiles and test under documented conditions.
17. **What makes a benchmark representative?** It reflects expected query distribution, difficulty, languages, edge cases, and failure modes, with labels created independently of system output.
18. **What is a quality gate?** A rule that fails a build when a metric violates a pre-agreed threshold. The threshold must account for sample size and trade-offs.
19. **How do you avoid overfitting to a benchmark?** Keep test data held out, rotate or refresh evaluation sets, and combine offline benchmarks with monitoring and human review.
20. **What would you improve next?** Add claim-level citation entailment, human answer correctness, uncertainty estimates, dataset/version metadata, and explicit missingness for usage fields.

## Five debugging and system-design scenarios

1. **Recall drops after chunk-size changes.** Compare per-query rankings, inspect chunk boundaries and document IDs, then isolate retrieval settings from corpus changes before reverting or tuning.
2. **Token F1 improves but human ratings decline.** Treat the metric as misaligned; inspect errors, revise labels/metrics, and add human-rated correctness rather than optimizing lexical overlap.
3. **CI fails on one example only.** Check whether it is a genuine regression, a mislabeled example, or nondeterministic output. Keep the example if valid and document the expected behavior.
4. **Reported cost is zero.** Verify whether provider usage metadata was absent; zero may mean missing, not free. Track missingness explicitly before using cost gates.
5. **A team keeps tuning on test results.** Freeze the current test set, return to dev for iteration, and create a fresh independently labeled holdout if the old test has become part of the tuning loop.

## Likely interviewer objections

- **“These are toy data.”** Agree. The sample verifies the pipeline mechanics; meaningful claims require a larger, representative, labeled dataset.
- **“Token F1 is not correctness.”** Agree and explain that it is a diagnostic baseline, not a semantic judge.
- **“The semantic proxy isn't embeddings.”** Correct. It is a deterministic synonym-expanded lexical proxy; the architecture accepts real application predictions, and a genuine dense retrieval adapter is future work.
- **“Can this certify production readiness?”** No. It provides evaluation plumbing and gates, not a complete safety or release process.
