# Evaluation protocol

1. Define the task and label relevant source IDs, reference answers, support facts, and expected citation IDs before generating predictions.
2. Freeze dataset version and record the code/configuration/prompt/model versions for each run.
3. Use `dev` for iteration. Keep `test` untouched until the approach and thresholds are selected.
4. Run all configurations on the same examples and same `k`.
5. Review per-example errors: missed retrieval, wrong ranking, unsupported response, missing citation, invalid citation, and unexpectedly high latency/cost.
6. Add deterministic tests for known failure cases and only gate CI on metrics whose labels and limitations are understood.
7. For production claims, use a larger representative dataset, human review, confidence intervals or repeated runs where stochasticity matters, and task-specific safety checks.

## Planned extensions

- Citation entailment checks at claim level.
- Human-labeled answer correctness and abstention quality.
- Optional model-based judging with calibration and judge-version tracking.
- Bootstrap confidence intervals and experiment metadata registry.
- Token/cost missingness indicators rather than default-zero aggregation.
