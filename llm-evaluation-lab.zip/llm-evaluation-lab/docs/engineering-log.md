# Engineering log

## 2026-10-25 — Initial implementation

- Added typed JSONL schemas and validation for evaluation examples and predictions.
- Implemented Recall@k, MRR, binary nDCG@k, token F1, support-fact coverage, and citation-ID precision.
- Added a runner with split selection, ID alignment, aggregate/per-example JSON reports, and a Recall@k gate.
- Added deterministic demo predictions and a report comparison command.
- Added a synthetic development/test dataset, unit tests, README, protocol docs, and GitHub Actions CI.

### Verification status

Not yet executed at the time of this log. The engineering log must be updated with actual command output after verification. Demo runs are educational ranking proxies, not measured performance of a production retrieval implementation.

### Known limitations

- `support_coverage` is lexical overlap only.
- The demo `semantic_proxy_demo` uses a small hand-written synonym map, not an embedding model.
- Missing latency/tokens/cost are reported as null and excluded from means.
- `expected_citations` are used as the known citation-ID set; claim-level support is not checked.

### Verification update

- `python -m compileall -q src tests`: passed.
- `python -m pytest -q`: 9 passed.
- CLI demo generation, dev evaluation for three configurations, report comparison, and held-out test evaluation: completed successfully.
- `ruff` and Docker executables were not available in this environment; their checks remain outstanding.
- Results and their limitations are documented in `docs/sample-results.md`.
