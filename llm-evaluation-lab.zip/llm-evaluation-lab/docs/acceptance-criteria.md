# Acceptance criteria

## Initial MVP

- [x] Read versionable JSONL dataset and prediction records.
- [x] Reject malformed required fields, invalid splits, invalid numeric values, missing predictions, and duplicate prediction IDs.
- [x] Calculate Recall@k, MRR, nDCG@k, token F1, support-fact coverage, and citation-ID precision.
- [x] Aggregate optional latency, token, and cost fields without treating missing values as zero.
- [x] Write JSON report with aggregate and per-example metrics.
- [x] Apply configurable Recall@k threshold and exit non-zero on gate failure.
- [x] Include a synthetic dataset with separate development and test examples.
- [x] Include deterministic demo predictions, unit tests, and CI configuration.
- [ ] Add human-labeled semantic correctness and claim-level citation entailment evaluation.
- [ ] Validate on a larger, representative dataset from an actual application.
- [ ] Verify Ruff and GitHub Actions in a clean install environment.

## Release gate

Do not call this a production-grade evaluation benchmark until the remaining items are complete. The current version is an MVP evaluation harness and teaching portfolio project.
