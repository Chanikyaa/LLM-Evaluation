# Portfolio tracker

| Project | Target role | Core technologies | Implementation | Tests | Evaluation | Deployment | GitHub |
|---|---|---|---|---|---|---|---|
| Hybrid Search RAG | GenAI / AI Engineer | Python, FastAPI, BM25, vector retrieval | Existing MVP; verify before release | Previously reported 10 tests; rerun before publishing | Small synthetic retrieval experiment; not conclusive | Local/Docker configuration; Docker build needs verification | Not published |
| LLM Evaluation Lab | AI/ML Engineer, MLOps | Python, JSONL, retrieval metrics, pytest, CI | MVP implemented | 9 tests passed locally | Demo run completed; tiny synthetic ranking proxies only | CLI local; no service deployment needed | Not published |
| End-to-End Classical ML | ML Engineer / Data Scientist | Planned | Not started | Not started | Not started | Not started | Not published |
| Production LLM API | AI Engineer | Planned | Not started | Not started | Not started | Not started | Not published |
| MLOps Pipeline | MLOps / ML Engineer | Planned | Not started | Not started | Not started | Not started | Not published |
| Tool-Calling Agent | GenAI Engineer | Planned | Not started | Not started | Not started | Not started | Not published |
| Multimodal Document Intelligence | Applied AI | Planned | Not started | Not started | Not started | Not started | Not published |
| AI Workflow Automation | Applied AI / Backend | Planned | Not started | Not started | Not started | Not started | Not published |
| MCP Server | AI Platform Engineer | Planned | Not started | Not started | Not started | Not started | Not published |
| Domain Fine-Tuning | GenAI / NLP | Planned | Not started | Not started | Not started | Not started | Not published |
| Forecasting or Recommendation | ML Engineer / Data Scientist | Planned | Not started | Not started | Not started | Not started | Not published |

Update statuses only after rerunning the relevant checks. A repository is not ready to publish until code, docs, evaluation, security review, and a clean-checkout run are verified.
