#!/usr/bin/env sh
set -eu
llm-eval demo-predictions --dataset data/dataset.jsonl --output-dir runs/predictions
mkdir -p runs/reports
for config in bm25_demo semantic_proxy_demo hybrid_demo; do
  llm-eval run --dataset data/dataset.jsonl \
    --predictions "runs/predictions/${config}.jsonl" \
    --output "runs/reports/${config}-dev.json" --split dev -k 3
done
llm-eval compare --reports runs/reports/bm25_demo-dev.json \
  runs/reports/semantic_proxy_demo-dev.json runs/reports/hybrid_demo-dev.json \
  --output runs/reports/comparison.json
