import pytest

from llm_eval.metrics import citation_precision, ndcg_at_k, recall_at_k, reciprocal_rank, token_f1


def test_recall_at_k():
    assert recall_at_k(["a", "b"], ["x", "b", "a"], 2) == 0.5


def test_mrr_uses_first_relevant_result():
    assert reciprocal_rank(["a", "b"], ["x", "b", "a"]) == 0.5


def test_ndcg_perfect_ranking_is_one():
    assert ndcg_at_k(["a", "b"], ["a", "b", "x"], 3) == pytest.approx(1.0)


def test_rejects_invalid_k():
    with pytest.raises(ValueError):
        recall_at_k(["a"], ["a"], 0)


def test_token_f1_and_citation_precision():
    assert token_f1("hello world", "hello world") == 1.0
    assert citation_precision(["doc1", "bad"], ["doc1"]) == 0.5
    assert citation_precision([], ["doc1"]) == 0.0
