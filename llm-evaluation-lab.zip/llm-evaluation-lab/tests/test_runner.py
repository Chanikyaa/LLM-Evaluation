import json
from pathlib import Path

import pytest

from llm_eval.runner import EvaluationGateError, evaluate, make_demo_predictions

ROOT = Path(__file__).resolve().parents[1]


def test_demo_predictions_and_evaluation(tmp_path):
    prediction_paths = make_demo_predictions(ROOT / "data/dataset.jsonl", tmp_path / "predictions")
    assert len(prediction_paths) == 3
    report_path = tmp_path / "report.json"
    report = evaluate(ROOT / "data/dataset.jsonl", prediction_paths[0], report_path, split="dev", k=3)
    assert report["summary"]["examples_evaluated"] == 6.0
    assert report_path.exists()
    assert json.loads(report_path.read_text())["config_name"] == "bm25_demo"


def test_gate_failure_writes_report(tmp_path):
    predictions = make_demo_predictions(ROOT / "data/dataset.jsonl", tmp_path / "predictions")[0]
    report_path = tmp_path / "report.json"
    with pytest.raises(EvaluationGateError):
        evaluate(ROOT / "data/dataset.jsonl", predictions, report_path, min_recall_at_k=1.1)
    assert report_path.exists()
