import pytest

from llm_eval.models import EvalExample, Prediction, RecordError


def test_dataset_rejects_invalid_split():
    with pytest.raises(RecordError, match="split"):
        EvalExample.from_dict({"example_id":"x", "split":"test-set", "question":"q", "relevant_doc_ids":[], "reference_answer":"a"})


def test_prediction_rejects_negative_latency():
    with pytest.raises(RecordError, match="negative"):
        Prediction.from_dict({"example_id":"x", "config_name":"c", "retrieved_doc_ids":[], "answer":"a", "latency_ms":-1})
