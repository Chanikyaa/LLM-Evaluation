# LLM Evaluation Lab

A provider-agnostic, reproducible evaluation pipeline for retrieval-augmented generation (RAG) and LLM applications. It scores retrieved rankings, answer/reference lexical overlap, labeled support-fact coverage, citation IDs, latency, token counts, and cost fields; exports JSON reports; and supports threshold gates for CI.

> **Honesty note:** lexical metrics are useful diagnostics, not semantic truth. The bundled `*_demo` runs use synthetic documents and deterministic ranking proxies. They do not call an LLM, do not establish production performance, and do not prove that hybrid retrieval is superior. Real application outputs should be evaluated with the same schema.

## Problem and intended users

Teams changing prompts, retrievers, models, or chunking strategies need a repeatable way to detect regressions. This repository provides a small evaluation harness that can be run locally or in CI without paid APIs.

## Features

- Versionable JSONL examples with explicit `dev` and held-out `test` splits.
- Retrieval metrics: Recall@k, MRR, and nDCG@k.
- Diagnostic answer metrics: token F1 and labeled support-fact coverage.
- Citation-ID precision checks against labeled expected sources.
- Latency, input/output token, and cost aggregation when provided.
- Per-example error inspection in JSON reports.
- Configurable Recall@k gate suitable for CI.
- Deterministic demonstration predictions for baseline comparison.
- Strict record validation, CLI, tests, and GitHub Actions.

## Non-goals and limitations

- No model or provider is called by the default implementation.
- Token F1 and support coverage do not understand paraphrases reliably and cannot establish factual correctness or groundedness.
- Citation precision checks source identifiers only; they do not validate that every claim is supported by the cited passage.
- The demo ranking methods are deliberately small educational proxies, not production BM25 or embedding models. The demo does not run answer generation; answer metrics therefore are not a meaningful result from those runs.
- Cost is only meaningful when supplied from a provider's usage metadata and pricing assumptions.
- A CI gate on a tiny synthetic set is a wiring check, not a quality guarantee.

## Architecture

```mermaid
flowchart TD
    A[Versioned JSONL dataset] --> B[Schema validation]
    C[Application prediction JSONL] --> B
    B --> D[Split and example alignment]
    D --> E[Retrieval metrics]
    D --> F[Answer and citation diagnostics]
    D --> G[Latency, token, cost aggregation]
    E --> H[Per-example and aggregate report]
    F --> H
    G --> H
    H --> I{Optional CI threshold}
    I --> J[Pass or fail]
```

## Technology choices

- **Python 3.10+**: accessible, widely used in ML engineering.
- **Standard library runtime**: makes core metrics and report generation cheap and offline-friendly.
- **JSONL**: diff-friendly, streamable, and straightforward to version.
- **pytest / Ruff**: optional development dependencies for tests and static checks.
- **GitHub Actions**: reproducible CI on pushes and pull requests.

## Prerequisites and installation

Python 3.10 or newer is required. A virtual environment is recommended.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
```

The core evaluator has no runtime third-party dependencies. Installing the `dev` extra requires access to a package index unless the packages are already available locally.

## Quick start

Generate deterministic sample predictions:

```bash
llm-eval demo-predictions --dataset data/dataset.jsonl --output-dir runs/predictions
```

Evaluate one configuration on the development split:

```bash
llm-eval run \
  --dataset data/dataset.jsonl \
  --predictions runs/predictions/bm25_demo.jsonl \
  --output runs/reports/bm25-dev.json \
  --split dev -k 3
```

Run the held-out test split only after selecting the approach on development data:

```bash
llm-eval run --dataset data/dataset.jsonl \
  --predictions runs/predictions/bm25_demo.jsonl \
  --output runs/reports/bm25-test.json --split test -k 3
```

Compare reports using the same split and `k`:

```bash
llm-eval compare \
  --reports runs/reports/bm25-dev.json runs/reports/semantic-dev.json runs/reports/hybrid-dev.json \
  --output runs/reports/comparison.json
```

Apply a Recall@3 gate (the report is written even when the gate fails):

```bash
llm-eval run --dataset data/dataset.jsonl \
  --predictions runs/predictions/bm25_demo.jsonl \
  --output runs/reports/gated.json --split dev -k 3 --min-recall-at-k 0.80
```

## Input formats

Each dataset JSONL line has `example_id`, `split` (`dev` or `test`), `question`, `relevant_doc_ids`, and `reference_answer`; `supporting_facts` and `expected_citations` are optional lists of strings. See `data/dataset.jsonl`.

Each predictions JSONL line has `example_id`, `config_name`, `retrieved_doc_ids`, `answer`, and optional `citations`, `latency_ms`, `input_tokens`, `output_tokens`, and `cost_usd`. See `examples/predictions.example.jsonl`.

Prediction files must contain exactly one configuration and one prediction for each selected example. Extra predictions for other splits are ignored. Missing selected examples and duplicates fail fast.

## Metrics

- **Recall@k**: fraction of labeled relevant documents found in the top `k` results.
- **MRR**: reciprocal rank of the first relevant document.
- **nDCG@k**: ranking quality with logarithmic position discount; relevance is binary in this implementation.
- **Token F1**: token overlap between generated and reference answer; sensitive to wording.
- **Support coverage**: fraction of human-labeled support facts with at least one token overlapping the answer. This is a weak diagnostic, not a claim-level entailment check.
- **Citation precision**: fraction of emitted citation IDs that appear in the expected source IDs. It does not check citation completeness or passage entailment.
- **Latency/tokens/cost**: averages of supplied fields. Missing values are reported as `null` in aggregate output and are excluded from means; `null` means unmeasured, not zero.

## Evaluation protocol

1. Add examples and labels before looking at system output. Keep the test split held out.
2. Run at least two configurations on the same selected split and `k`.
3. Inspect per-example failures, not only aggregate averages.
4. Choose settings using development data; use test data for final reporting only.
5. Include model/provider versions, prompt version, retrieval settings, dataset version, and pricing assumptions in experiment notes when using real systems.
6. Report uncertainty and dataset limitations. A tiny synthetic set is not representative of production traffic.

## Tests and quality checks

```bash
pytest
ruff check .
python -m compileall -q src tests
```

Only report checks as passed after running them in your environment. GitHub Actions installs the dev extra and runs tests plus Ruff.

## Example request / report

The CLI evaluates stored outputs rather than serving an API. Example prediction record:

```json
{"example_id":"dev-001","config_name":"my-rag-v1","retrieved_doc_ids":["incident_response","model_evaluation"],"answer":"Acknowledge severity one incident alerts within five minutes.","citations":["incident_response"],"latency_ms":182.4,"input_tokens":540,"output_tokens":22,"cost_usd":0.0008}
```

The output report includes a `summary`, per-example metric rows, split metadata, and interpretation warnings.

## Security and privacy

- Do not put API keys, private documents, or personal data in this repository.
- Treat evaluation datasets and model outputs as potentially sensitive; sanitize before committing.
- The tool reads the paths explicitly passed by the caller and writes reports to the requested path. Do not run untrusted datasets in privileged environments.
- The optional CI gate only checks a numeric metric; it does not approve a release or replace human review.

## Docker

The core CLI is lightweight. Docker support can be added once the runtime base image and dependency policy are chosen; no Dockerfile is included in this initial version to avoid a misleading unverified deployment claim.

## Personal engineering contribution

For portfolio presentation, describe only work you personally understand and can demonstrate. This starter implementation includes record validation, deterministic metrics, report generation, threshold gates, test fixtures, and CI wiring. Add your own experiments, error analysis, and measured results before presenting it as finished work.

## License

MIT. See `LICENSE`.
